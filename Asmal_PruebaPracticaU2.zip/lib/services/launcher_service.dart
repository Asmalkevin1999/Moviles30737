import 'package:url_launcher/url_launcher.dart';

class LauncherService {
  static Future<void> makePhoneCall(
      String phoneNumber) async {
    final Uri phoneUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );

    await launchUrl(phoneUri);
  }

  static Future<void> sendEmail(
      String email) async {
    final Uri emailUri = Uri(
      scheme: 'mailto',
      path: email,
      queryParameters: {
        'subject': 'Consulta Flutter',
        'body': 'Hola desde Flutter',
      },
    );

    await launchUrl(
      emailUri,
      mode: LaunchMode.externalApplication,
    );
  }
}