import 'package:flutter/material.dart';
import '../widgets/call_button.dart';

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Card(
        color: const Color(0xFF181818),
        elevation: 15,
        shadowColor: const Color(0xFF00C2FF),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [

              CircleAvatar(
                radius: 60,
                backgroundColor: Color(0xFF00C2FF),
                child: Icon(
                  Icons.headset_mic_rounded,
                  color: Colors.black,
                  size: 60,
                ),
              ),

              SizedBox(height: 20),

              Text(
                "Llamadas Telefónicas",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              SizedBox(height: 10),

              Text(
                "Presione el botón para comunicarse mediante una llamada telefónica.",
                textAlign: TextAlign.center,
              ),

              SizedBox(height: 20),

              CallButton(),
            ],
          ),
        ),
      ),
    );
  }
}