import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(
              Icons.hub_rounded,
              size: 130,
              color: Color(0xFF00C2FF),
            ),

            SizedBox(height: 20),

            Text(
              "Centro de Comunicación",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 15),

            Text(
              "Aplicación móvil desarrollada en Flutter para realizar llamadas telefónicas y enviar correos electrónicos utilizando las funciones nativas del dispositivo.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.white60,
              ),
            ),
          ],
        ),
      ),
    );
  }
}