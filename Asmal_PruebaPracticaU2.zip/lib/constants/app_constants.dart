import 'package:flutter/material.dart';

class AppConstants {
  static const String telefono = "0967303552";

  static const String correo = "correo@ejemplo.com";

  static const Color colorPrincipal =
  Color(0xFF00C2FF);
}