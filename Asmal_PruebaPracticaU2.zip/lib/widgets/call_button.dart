import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import '../services/launcher_service.dart';

class CallButton extends StatelessWidget {
  const CallButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () {
        LauncherService.makePhoneCall(
          AppConstants.telefono,
        );
      },
      icon: const Icon(Icons.call),
      label: const Text("Llamar"),
    );
  }
}