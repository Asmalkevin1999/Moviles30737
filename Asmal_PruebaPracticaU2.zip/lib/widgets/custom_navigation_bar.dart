import 'package:flutter/material.dart';

class CustomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: onTap,
      type: BottomNavigationBarType.fixed,
      items: const [

        BottomNavigationBarItem(
          icon: Icon(Icons.dashboard_customize_rounded),
          label: "Inicio",
        ),

        BottomNavigationBarItem(
          icon: Icon(Icons.headset_mic_rounded),
          label: "Llamadas",
        ),

        BottomNavigationBarItem(
          icon: Icon(Icons.mail_lock_rounded),
          label: "Correo",
        ),
      ],
    );
  }
}