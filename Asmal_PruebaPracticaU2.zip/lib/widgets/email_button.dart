import 'package:flutter/material.dart';
import '../constants/app_constants.dart';
import '../services/launcher_service.dart';

class EmailButton extends StatelessWidget {
  const EmailButton({super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () {
        LauncherService.sendEmail(
          AppConstants.correo,
        );
      },
      icon: const Icon(Icons.send),
      label: const Text("Enviar Correo"),
    );
  }
}